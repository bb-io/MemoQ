﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Apps.Memoq.Contracts;
using Apps.Memoq.Utils.FileUploader;
using Apps.Memoq.Utils.FileUploader.Managers.Base;
using Apps.Memoq.Utils.FileUploader.Managers;
using Blackbird.Applications.Sdk.Common.Authentication;
using MQS.FileManager;
using Blackbird.Applications.SDK.Extensions.FileManagement.Interfaces;
using Blackbird.Applications.Sdk.Common.Files;
using Apps.Memoq.Models.Termbases;
using Apps.Memoq.Models.Termbases.Requests;
using Apps.Memoq.Actions;
using Apps.Memoq.Models;
using Blackbird.Applications.Sdk.Common.Invocation;


namespace MemoqFileUploader
{
    class Program
    {
        static async Task Main(string[] args)
        {
            const string baseUrl = "https://memoq.blackbird.io:2053/memoqservices";
            const string apiKey = "XlJKK7avscDmTA7sjl1Jol1x2ETrSHziundwNySu";
            //const string filePath = @"D:\Some\some.txt";

            var authProviders = new InvocationContext()
            {
                AuthenticationCredentialsProviders = new List<AuthenticationCredentialsProvider>
                {
                    new AuthenticationCredentialsProvider("url", baseUrl),
                new AuthenticationCredentialsProvider("apiKey", apiKey)
                }  
            };



            using var fileServiceFactory = new MemoqServiceFactory<IFileManagerService>(SoapConstants.FileServiceUrl, authProviders.AuthenticationCredentialsProviders);
            var fileManagerService = fileServiceFactory.Service;
            var fileManagementClient = new FileManagementClient();


            string fileName = "Artem_test1.csv";

            var fileRef = new FileReference
            {
                Name = fileName,
                ContentType = "text/csv"
            };

            var glossaryWrapper = new GlossaryWrapper
            {
                Glossary = fileRef
            };

            var request = new CreateTermbaseRequest
            {
                ExistingTermbaseId = "639a061a-6c95-41ef-91b9-379b4db519ae",
                //AllowAddNewLanguages = true,
                //OverwriteEntriesWithSameId = false,
                //IsQTerm = false,
                //Name = "Artem test",
                //Description = "Testing import",
                //Client = "Acme Corp",
                //Project = "Project X",
                //Domain = "General",
                //Subject = "Greetings",
                //IsModerated = false
            };

            var actionInstance = new TermBaseActions(authProviders, fileManagerService, fileManagementClient );

            try
            {
                var response = await actionInstance.ImportTermbaseTest(glossaryWrapper, request);
                Console.WriteLine("ImportOK!");
                Console.WriteLine("Termbase GUID: " + response.TermbaseGuid);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Import failed: " + ex.Message);
            }

        }
    }

    public class FileManagementClient : IFileManagementClient
    {
        private const string PathFolder = @"D:\Some\";

        public Task<FileReference> UploadAsync(Stream stream, string contentType, string fileName)
        {
            var filePath = System.IO.Path.Combine(PathFolder, fileName);
            using var fileStream = File.Create(filePath);
            stream.CopyTo(fileStream);

            return Task.FromResult(new FileReference
            {
                Name = fileName,
                ContentType = contentType,
            });
        }

        public Task<Stream> DownloadAsync(FileReference reference)
        {
            var filePath = System.IO.Path.Combine(PathFolder, reference.Name);

            if (!File.Exists(filePath))
                throw new FileNotFoundException($"File not found at path: {filePath}");

            return Task.FromResult<Stream>(File.OpenRead(filePath));
        }
    }
}